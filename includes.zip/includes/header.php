<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>
    <?php 
       echo $page_title;
    ?>
</title>
    <meta name="google-site-verification" content="D7NGa4hx8YVzL8ns4xEZoOCUzgiazjUJ6dWxJvEVqJc" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="<?php echo $page_keywords; ?>" name="keywords">
  <meta content="<?php echo $page_description ;?>" name="description">
  <link href="/img/u_logo.ico" rel="icon">
 <!-- ajax call for header footer -->
 <script
    src="https://code.jquery.com/jquery-3.3.1.js"
    integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
    crossorigin="anonymous">
</script>
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-Ld7x/STpO0wNKM41ut5QxDJ3NpfPt1eMRHfLcS1QBUzGHM1sYgPw1tYUA3vcBmjBDsZ4SkMmsOlK7cfFFaVh6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

  <link href="/lib/animate/animate.min.css" rel="stylesheet">
  <link href="/lib/venobox/venobox.css" rel="stylesheet">
  <link href="/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha384-...your-integrity-hash... " crossorigin="anonymous">

  <!-- Main Stylesheet File -->
  <link href="/css/style.css" rel="stylesheet">
</head>
<body>
    <?php 
        if($page_name == 'home') {
            echo '<header id="header">';
        }else {
            echo '<header id="header" class="header-fixed">';
        }
    ?>
    <div class="container">
      <div id="logo" class="pull-left">
        <?php
          if($page_name == 'home') {
            echo '<a href="#intro" class="scrollto"><img src="/img/UPES Transparent white-01.png" alt="" title=""></a>';
          }else {
            echo '<a href="/#intro" class="scrollto"><img src="/img/UPES Transparent white-01.png" alt="" title=""></a>';
          }
        ?>
      </div>
      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <?php 
            if($page_name == 'home' || $page_name == '') {
            echo '<li class="menu-active"><a href="#intro">Home</a></li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About</a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: #343a40";>
                    <div class="dropdown-item about-us"><a href="/about" style="color: white";>About Us</a></div>
                    <div class="dropdown-item about-us"><a href="/organising"  style="color: white";>Organising Committee</a></div>
                    <div class="dropdown-item about-us"><a href="/advisory"  style="color: white";>Advisory Committee</a></div>
                </div>
                </li>
            <li><a href="/speakers">Speakers</a></li>
            <li><a href="#schedule">Schedule</a></li>
            <li><a href="#callforpaper">Call for Papers</a></li>
            <li><a href="#important-dates">Important Dates</a></li>
            <!-- <li><a href="#gallery">Gallery</a></li> -->
            <li><a href="/accomodation">Accommodation</a></li>
            <li><a href="#supporters">Sponsors</a></li>
            <li><a href="#contact">Contact</a></li>
            <li class="buy-tickets"><a href="#buy-tickets">Register Now </a></li>';
            }else {
                echo '<li class="menu-active"><a href="/"><i class="fas fa-arrow-left"></i> Go Back to Home </i></a></li>';
            }
          ?>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->