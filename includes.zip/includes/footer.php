<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div id="logo-footer" class="col-lg-4 col-md-6 footer-info">
            <img loading="lazy" id="logo-foot" src="/img/UPES Transparent white-01.png" alt="UPES">
          </div>
  
          <div class="col-lg-4 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              UPES, Bidholi Campus, Dehradun<br>
              P.O. Bidholi Via Premnagar, <br>
              Dehradun-248007<br>
              <strong>Phone:</strong> 1800 1028 737<br>
              <strong>Email:</strong> energysummit2024@ddn.upes.ac.in<br>
            </p>
  
            <div class="social-links">
              <a href="https://x.com/upesdehradun?s=21" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="https://www.facebook.com/share/EbgKQKYsBJ9gGaB1/?mibextid=sCpJLy" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="https://www.instagram.com/upes_dehradun?igsh=ejgxcDYxMzZkaHk2 " class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="https://youtube.com/@UPES?si=J_r6upSHBJOeQMUA" class="youtube"><i class="fa fa-youtube"></i></a>
              <a href="https://www.linkedin.com/school/upesdehradun/" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>
          </div>
  
          <div class="col-lg-4 venue-map">
            <iframe loading="lazy" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3440.694439524779!2d77.96429537526542!3d30.416410124738434!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3908d4890d7c1735%3A0x22d3ae324c238e3c!2sUPES!5e0!3m2!1sen!2sin!4v1709041890181!5m2!1sen!2sin" style="border:0; height: 250px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div>
        </div>
      </div>
    </div>
  
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>Energy Summit, UPES</strong>. All Rights Reserved
      </div>
    </div>
  </footer>
  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>
  <script src="/lib/jquery/jquery.min.js"></script>
  <script src="/lib/jquery/jquery-migrate.min.js"></script>
  <script src="/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="/lib/easing/easing.min.js"></script>
  <script src="/lib/superfish/hoverIntent.js"></script>
  <script src="/lib/superfish/superfish.min.js"></script>
  <script src="/lib/wow/wow.min.js"></script>
  <script src="/lib/venobox/venobox.min.js"></script>
  <script src="/lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="/js/main.js"></script>
  <script src="https://kit.fontawesome.com/b3547a0afb.js" crossorigin="anonymous"></script>
</body>
</html>