
<style>
    /* Target all images within the section with the class "speakers" */
    .speaker {
      width: 250px;
      height: 300px;
      overflow: hidden; /* Ensures that any overflow is hidden */
      border: 2px solid #f82249;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
  }
  
  .speaker img{
      width: 100%;
      height: 100%;
      object-fit: cover; /* Ensures that the entire image is visible without cropping */
  }
  .details{
    border: 2px solid rgba(0, 0, 0, 0.319);
    border-top-left-radius: 10px;
      border-top-right-radius: 10px;
    /* font-size: 20px; */
      /* margin: 0px; */
  }
  .details h3{
    /* font-size: 50px; */
  }
  #speakers .speaker .details a {
    color: #fff;
    /* font-size: 18px; */
}
#speakers .speaker .details p {
    color: #fff;
    /* font-size: 15px; */
}


  </style>
<br>
<br>
  <section id="speakers" class="wow fadeInUp">
    <div class="container">
      <div class="section-header">
        <h2>Invited Speakers</h2>
        <!-- <p>Here are some of our speakers</p> -->
      </div>

      <div class="row" style="display: flex; justify-content: space-evenly;">
        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/1"><img loading="lazy" src="img/speakers/hemanta.png" alt="Speaker 1" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/1">Dr. Hemanta Sarma </a></h3>
              <p>Professor<br>University of Calgary</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/16"><img loading="lazy" src="img/speakers/16.jpg" alt="Speaker 2" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/16">Dr. Ajay K. Ray </a></h3>
              <p>Professor<br>University Of Western Ontario</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/2"><img loading="lazy" src="img/speakers/Dr. james Peters.jpg" alt="Speaker 2" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/2">Dr. James Peters</a></h3>
              <p>Independent Consultant<br>Oil & Gas (E&P)</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/3"><img loading="lazy"loading="lazy"  src="img/speakers/Mr. Kapil Bansal.jpg" alt="Speaker 2" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/3">Mr. Kapil Bansal</a></h3>
              <p>Partner<br>EY Energy Transition and Decarbonization</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/4"><img loading="lazy"loading="lazy" src="img/speakers/Dr. Vikram vishal.JPG" alt="Speaker 4" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/4">Dr. Vikram Vishal</a></h3>
              <p>Professor<br>IIT Bombay</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
        
       
        <!-- amit kumar -->
        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/6"><img loading="lazy"loading="lazy" src="img/speakers/amit.jpg" alt="Speaker 2" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/6">Dr. Amit Kumar</a></h3>
              <p>Senior Scientist
                <br>Shenzhen University, China</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/20"><img loading="lazy"loading="lazy" src="img/speakers/bagchi.jpg" alt="Speaker 2" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/20">Ms Nebula Bagchi</a></h3>
              <p>Group General Manager<br>ONGC Ltd</p>
             
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/7"><img loading="lazy"loading="lazy" src="img/speakers/Dr. Pratik Dutta.jpg" alt="Speaker 2" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/7">Dr. Pratik Dutta</a></h3>
              <p>Professor<br>IIEST Shibpur</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
         <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/19"><img loading="lazy" src="img/speakers/rsrawat.jpg" alt="Speaker 5" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/19">Dr. RS Rawat</a></h3>
              <p>Scientist ‘E’ <br />Indian Council of Forestry Research and Education, Dehradun.</p>
              <!-- <p></p> -->
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/8"><img loading="lazy"loading="lazy" src="img/speakers/Mr. Debabrata Tripathy.jpg" alt="Speaker 2" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/8">Mr. Debabrata Tripathi</a></h3>
              <p>AGM (P&S)<br>NTPC Ltd</p>
              
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/14"><img loading="lazy"loading="lazy" src="img/speakers/debasis.jpg" alt="Speaker 3" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/14">Dr. Debasis Das</a></h3>
              <p>Project Lead <br>CCS, Petronas</p>
              
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/9"><img loading="lazy"loading="lazy" src="img/speakers/rakesh.jpg" alt="Speaker 2" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/9">Mr. Rakesh Vankayala</a></h3>
              <p>Manager (R&D)<br>BPCL, CDRC</p> 
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="speaker" style="height:300px;">
            <img loading="lazy" src="img/speakers/rajkumar.jpg" alt="Speaker 6" class="img-fluid">
            <div class="details">
              <h3><a href="speaker-details/15">Dr. Raj Kumar Arya</a></h3>
              <p>Associate Professor <br/> Dr B R Ambedkar NIT, Jalandhar</p>
              <div class="social">
                <!--<a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a>-->
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/10"><img loading="lazy" src="img/speakers/Purushottam uniyal.png" alt="Speaker 5" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/10">Mr. Purushottam Uniyal</a></h3>
              <p>Market Research Specialist-Sustainability<br>MarketsandMarkets Research Pvt. Ltd.</p>
              <!-- <p></p> -->
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
         <div class="col-lg-4 col-md-6">
          <div class="speaker">
            <a href="/speaker-details/11"><img loading="lazy" src="img/speakers/Dr. Rajesh Tripathi_sir.jpg" alt="Speaker 3" class="img-fluid"></a>
            <div class="details">
              <h3><a href="/speaker-details/11">Dr. Rajesh Tripathi</a></h3>
              <p>Associate Professor<br>UPES, Dehradun</p>
              
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
         
      </div>
    </div>

  </section>
