
<main id="main" class="main-page">
<section id="speakers-details" class="wow fadeIn">
  <div class="container">
    <div class="section-header">
      <h2>ABOUT US</h2>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="details">
          <h2>UPES, DEHRADUN</h2>
          <div class="social">
            <a href="https://x.com/upesdehradun?s=21" class="twitter"><i class="fa fa-twitter"></i></a>
            <a href="https://www.facebook.com/share/EbgKQKYsBJ9gGaB1/?mibextid=sCpJLy" class="facebook"><i class="fa fa-facebook"></i></a>
            <a href="https://www.instagram.com/upes_dehradun?igsh=ejgxcDYxMzZkaHk2 " class="instagram"><i class="fa fa-instagram"></i></a>
            <a href="https://youtube.com/@UPES?si=J_r6upSHBJOeQMUA" class="youtube"><i class="fa fa-youtube"></i></a>
            <a href="https://www.linkedin.com/school/upesdehradun/" class="linkedin"><i class="fa fa-linkedin"></i></a>
          </div>
          <p style="text-align: justify";>Established through the UPES Act, 2003 of the State Legislature of Uttarakhand, UPES is
            one of the top-ranked, UGC-recognized, private universities. As per the National Institutional
            Ranking Framework (NIRF) 2023, the Ministry of Education, India, UPES has been ranked
            46th, with a rank of 42 in engineering and a rank of 39 in management. In addition to this, the
            university was recently ranked 1 in academic reputation in India by the QS World University
            Rankings 2024 and is among the top 3% of universities in the world. UPES has also been
            accredited by NAAC with an accreditation grade ‘A’ and has received 5-Stars on
            Employability (placements), by globally acclaimed QS Rating. UPES offers graduate and
            postgraduate programs through its eight schools: School of Advanced Engineering, School of
            Computer Science, School of Design, School of Law, School of Business, School of Health
            Sciences &amp; Technology, School of Modern Media, and School of Liberal Studies. The
            university’s singular purpose is to enable each one to achieve their purpose in life, through
            the guiding light of knowledge. Each one is empowered to pursue dreams and passion in a
            meaningful and responsible manner. Each one is encouraged to foster professional
            development through imagination, innovation, specialised knowledge and critical thinking.
            Each one is entrusted to become an active participant in transforming society, to go beyond
            oneself, to respect and inclusively contribute in a pluralistic world. Thus, enabling one to
            choose life pathways that fulfil their purposes fruitfully.</p>
        </div>
      </div>

      <div class="col-md-6" style="position: relative;">
        <img loading="lazy" src="./img/about_us/campus-image.jpg" alt="campus-image" class="img-fluid" >
      </div>
      
    </div>
  </div>
</section>

<section id="speakers-details" class="wow fadeIn">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <img loading="lazy" src="img/about_us/Energy Cluster (1).svg" alt="energy-cluster" class="img-fluid" >
      </div>

      <div class="col-md-6">
        <div class="details">
          <h2>ENERGY CLUSTER, UPES</h2>
          <p style="text-align: justify";>The Energy Cluster at UPES is a leading institution for education and research in the energy
            sector. It offers a wide range of undergraduate and postgraduate programs, and its research
            focuses on sustainable development, clean energy, and disaster management. The cluster is
            committed to providing students with a holistic education that prepares them for the future of
            work.</p>

          <p style="text-align: justify";>The cluster was established in 2003 and now offers three undergraduate and four
            postgraduate degrees. The undergraduate programs include B.Tech Applied Petroleum Engineering,
            B.Tech Chemical Engineering, and B.Sc Geology. The postgraduate programs are M.Tech Petroleum Engineering, M.Tech Chemical Engineering, M.Tech in
            Renewable Energy and M.Sc Applied Geology.</p>

          <p style="text-align: justify";>The curriculum at the Energy Cluster is designed to give students the skills they need to
            succeed in the energy sector. Courses include data analytics, digitization, automation of
            processes, Al/ML, etc. The cluster also offers life skills courses like critical thinking, living
            conversations, learning how to learn, etc.</p>

          <p style="text-align: justify";>The Energy Cluster at UPES is where leaders of tomorrow are built. The cluster is committed
            to providing students with the knowledge and skills they need to make a difference in the
            world.</p>

          
        </div>
      </div>
      
    </div>
  </div>

</section>

<section id="speakers-details" class="wow fadeIn">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="details">
          <h2>ABOUT CONFERENCE</h2>
          <p style="text-align: justify";>International Conference on Navigating Global Energy Transition for a Sustainable Future
            (ICNETS 2024), a transformative conference that brings together industry leaders, policy makers,
            innovators, and visionaries together to delve into the complex challenges and opportunities
            associated with the ongoing global energy transition. In Energy Summit 2024,
            participants/attendees will be engaged in dynamic discussions, sharing insights and
            innovative solutions aimed at steering the world towards a more sustainable and
            environment-friendly energy landscape. The conference features keynote addresses from
            leaders in the field of energy, geosciences; interactive panel sessions, and collaborative
            workshops that explore a wide range of topics. The key areas include carbon capture
            utilization and storage (CCUS), renewable energy integration, energy efficiency, carbon
            neutrality strategies, policy frameworks and regulations, global carbon markets, and the role
            of emerging technologies, and many more. With a focus on fostering insightful discussions,
            share groundbreaking ideas and create networking opportunities that drive growth and innovation in
            industry, this conference will play a pivotal role in shaping a resilient and sustainable future for
            the global energy sector.</p>
        </div>
      </div>
      <div class="col-md-6">
        <img loading="lazy" src="img/about_us/About Conference Image.svg" alt="conference-image" class="img-fluid">
      </div>
    </div>
  </div>
</section>
</main>