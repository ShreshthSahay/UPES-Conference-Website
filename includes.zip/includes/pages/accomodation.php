<style>/* Style for hostel images */
    .hostel-image {
    width: 100%;
    height: auto;
    object-fit: cover; /* Ensures the image covers the entire container */
    }

    /* Style for hostel details */
    .details {
    padding: 20px;
    }

    #title {
    font-size: 34px;
    font-weight: bold;
    margin-bottom: 10px;
    justify-content: center;
    display: flex;
    }

    #description {
    font-size: 22px;
    color: #555;
    margin-bottom: 20px;
    justify-content: center;
    display: flex;
    }
    .row .col-md-6 {
    padding: 0 15px; /* Add padding to the columns */
    }
    .row .image{
    display: flex;
        justify-content: center; /* Center horizontally */
        align-items: center; /* Center vertically */
    }

    .row .image img {
    /* width: 100%; */
    /* height: auto; */
    margin-bottom: 20px; /* Add margin to the bottom of the images */
    border:solid #555 2px;
    border-radius: 5px;
    width: 50%; /* Ensure images fill their container */
    height:200px; /* Set a specific height for all images */
    /* align-items: center;
    display: flex; */
    }
    .section-header{
    font-size: 37px;
    }

</style>

<main id="main" class="main-page">

  <section id="accomodation">
    <div class="container">
      <div class="section-header">
        <br>
        <h2>List of Accomodation Options</h2>
        <p>Room availability may vary, and all costs to be borne by the individuals.</p>
      </div>
      <div class="row" style="align-items: center;">
        <div class="col-md-6 image">
          <img loading="lazy" src="img/hotels/orchid.jpg" alt="hostel 1" class="img-fluid" id="image">
        </div>

        <div class="col-md-6">
          <div class="details">
            <h2 id="title">Your-Space Orchid Homes Boys Hostel, Kandoli </h2>
           
            <p id="description">Mr. Rajat - 9897097006 <a href="tel:+919897097006"><i class="fas fa-phone-alt"></i></a></p>

            </div>
        </div>
        </div>
        
    
        
        
          <div class="row">
            <div class="col-md-6 image">
              <img loading="lazy" src="img/hotels/elemento1.png" alt="hostel 4" class="img-fluid" id="image">
            </div>
          
            <div class="col-md-6">
              <div class="details">
                <h2 id="title">Elemento Girls Hostel, Bidholi 
                </h2>
                <p id="description">Mr. Jaspreet - 9759554445<a href="tel:+919759554445"><i class="fas fa-phone-alt"></i></a></p>
              </div>
            </div>
          </div>
        </div> 
      </div>
  </section>
</main>