<div class="section-header">
    <h2>ADVISORY COMMITTEE</h2>
</div>
<div class="container">
    <h2 class="text-center font-weight-bold">International Advisory Committee</h2>
  <div class="container">
  <table class="responsive-table">
    <thead>
      <tr>
        <th colspan="4" style="text-align: center !important;">Details</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Dr. Mika Sillanpaa</strong>
        </a><br><em>Professor</em><br>Dept. Of Environmental Engineering, University of Johannesburg</td>
        <td><strong>Dr. Mohamed Abioui</strong>
        </a><br><em>Professor</em><br>Dept. of Earth Sciences, Ibnou Zohr University, Morocco</td>
        <td><strong>Dr. Hemanta Sarma</strong>
        </a><br><em>Professor</em><br>Dept. of Petroleum Engineering, University of Calgary</td>
        <td><strong>Dr. Hari Vuthaluru</strong>
        </a><br><em>Professor</em><br>Dept. of Chemical Engineering, Curtin University, Australia</td>
      </tr>
      <tr>
        <td><strong>Dr. Nagababu Andraju</strong>
        </a><br><em>Research Engineer</em><br>CEM Research Institute, University of North Dakota, USA</td>
        <td><strong>Dr. Rohit Pandey</strong>
        </a><br><em>Associate Professor</em><br>Dept. Of Mining and Minerals Engineering, Virginia Tech, USA</td>
        <td><strong>Dr. Satyabrata Nayak</strong>
        </a><br><em>Principal</em><br>Petroleum Geosciences, Petronas, Kuala Lumpur, Malaysia</td>
      </tr>
    </tbody>
  </table>
</div>
<br>
    <h2 class="text-center font-weight-bold">National Advisory Committee</h2>
    <style>
      .responsive-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
      }
      .responsive-table th,
      .responsive-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left !important;
        direction: ltr;
        vertical-align: top;
        
      }
      .responsive-table th {
        background-color: #f2f2f2;
      }
      @media screen and (max-width: 600px) {
    .responsive-table {
      overflow-x: auto;
      font-size: 12px; /* Adjust font size for smaller screens */
    }
  }
      /* Responsive styles */
@media (max-width: 768px) {
  .responsive-table thead {
    display: none;
  }
  
  .responsive-table tr {
    display: block;
    margin-bottom: 20px;
    border: 1px solid #ddd;
  }

  .responsive-table td {
    display: block;
    text-align: left;
  }

  .responsive-table td strong {
    display: block;
    margin-bottom: 5px;
  }

  .responsive-table td em {
    display: block;
    margin-bottom: 10px;
  }
}
    </style>
  
  <div class="container">
        <table class="responsive-table">
            <thead>
            <tr>
                <th colspan="4" style="text-align: center;">Details</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><strong>Dr. Tapas Kumar Dora</strong>
                </a><br><em>Senior Research Scientist</em><br>Reliance Industries Limited, Gujarat</td>

            
                <td><strong>Dr. Shivanjali Sharma</strong>
                </a><br><em>Associate Professor</em><br>Department of Petroleum Engineering and Geosciences, RGIPT, Jais, Uttar Pradesh</td>
            
            
                <td><strong>Dr. Akhila Kumar Sahu</strong>
                </a><br><em>Principal Scientist</em><br>CSIR-Central Electrochemical Research Institute, Chennai, Tamil Nadu</td>
            
            
                <td><strong>Mr. Ramesh Gannamani</strong>
                </a><br><em>FEA Consultant</em><br>Finitum Technologies, Andhra Pradesh.</td>
            </tr>
            <tr>
                <td><strong>Dr. Sayantan Ghosh</strong>
                </a><br><em>Assistant Professor</em><br>Department of Petroleum Engineering, IIT-ISM, Dhanbad, Jharkhand</td>
            
            
                <td><strong>Dr. Vikash Mahto</strong>
                </a><br><em>Professor</em><br>Department of Petroleum Engineering, IIT-ISM, Dhanbad, Jharkhand</td>
            
            
                <td><strong> Dr. R. J. Krupadam</strong>
                </a><br><em>Chief Scientist and Head</em><br>CSIR-NEERI, Nagpur, Maharashtra</td>
            
                <td><strong>Dr. Prabodha Ranjan Sahoo</strong>
                </a><br><em>Associate Professor</em><br>Dept. of Applied Geology, IIT-ISM, Dhanbad, Jharkhand</td>
            </tr>
            <tr>
                <td><strong>Dr. Harsh Kumar Verma</strong>
                </a><br><em>Senior Principal Scientist and Head of Section</em><br>CSIR-CIMFR, Bilaspur, Chhattisgarh</td>
            
                <td><strong>Dr. Shailesh Kumar</strong>
                </a><br><em>Assistant Professor</em><br>Dept. of Petroleum Engineering, RGIPT, Jais, Amethi, Uttar Pradesh</td>
            
                <td><strong>Dr. Santanu Bhowmik</strong>
                </a><br><em>Assistant Professor</em><br>Dept. of Mining Engineering, NIT-Rourkela, Odisha</td>
            
                <td><strong>Dr. Prateek Dutta</strong>
                </a><br><em>Professor</em><br>Dept. Of Mining Engineering, IIEST-Shibpur, West Bengal</td>
            </tr>
            <tr>
                <td><strong>Mr. Ram Sharma</strong>
                </a><br><em>Associate Vice President</em><br>JSW-Steel, Odisha</td>
            
                <td><strong>Dr. Siddharth S</strong>
                </a><br><em>Associate Professor</em><br>PSN College of Engineering and Technology, Melathediyoor, Tamil Nadu</td>
            </tr>
            </tbody>
        </table>
    </div>
</div>