
<main id="main" class="main-page">
    <section id="speakers-details" class="wow fadeIn">
        <div class="container">
            <div class="section-header">
            <h2>Speaker Details</h2>
            </div>
            <?php
                if($name == '') {
                    echo "<center><h1>Speaker Not Found!</h1></center>";
                }
            ?>
            <div class="row">
                <div class="col-md-6">
                    <img loading="lazy" src="/<?php echo $image; ?>" alt="Speaker <?php echo $name; ?>" class="img-fluid" id="image">
                </div>
                <div class="col-md-6">
                    <div class="details">
                        <h2 id="title">
                            <?php echo $name; ?>
                        </h2>
                        <p style="white-space: pre-line; text-align: justify;"  id="description">
                            <?php echo $description; ?>
                        </p>
                    </div>
                </div>
            </div>
            <style>
            .speaker-details {
                width: 250px;
                height: 300px;
                overflow: hidden;
                border: 2px solid #f82249;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                text-align: center; /* Center align the content */
                }

                .speaker-details img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                }


                .speaker-details h1 {
                color: #333; /* Set text color */
                font-size: 24px; /* Set font size */
                margin-bottom: 10px; /* Add margin bottom for spacing */
                }

                .speaker-details p {
                color: #666; /* Set text color */
                font-size: 16px; /* Set font size */
                line-height: 1.5; /* Set line height for readability */
                margin-bottom: 20px; /* Add margin bottom for spacing */
                /*white-space: pre-line;*/
                }
            </style>
        </div>
    </section>
</main>
