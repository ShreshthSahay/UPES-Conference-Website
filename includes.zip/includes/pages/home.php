  <div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Notice</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        1. Deadline for abstract submission has advanced to 12th September.<br/>
        2. Registration kit will not be sent to the virtual participants.<br/>
        3. Authors registered/planning to go for publication in Discover Applied Sciences need to keep their manuscripts ready by 28th September 2024.
      </div>

    </div>
  </div>
</div>
<script type="text/javascript">
    $(window).on('load', function() {
        $('#myModal').modal('show');
    });
</script>
  <!--==========================
    Intro Section
  ============================-->
  <style>
      
     video{ 
        margin:0 auto;
        min-width: 100%;
        min-height: 100%;
        width: auto;
        height: auto;
        z-index: -100;
        background-size: cover;
        transition: 1s opacity;
    }
  </style>
  <section id="intro">
    <video preload="none" autoplay muted loop poster="/img/poster.cwebp" id="bg-video">
      <source src="/img/video.mp4" type="video/mp4">
      <!-- Add more source elements for different video formats if needed -->
      Your browser does not support the video tag.
    </video>
    <div class="intro-container">
      <h2 style="font-style: italic; font-weight: bold; color: white;  padding: 5px; font-family: 'Your Fancy Font', sans-serif;">Energy Summit 2024 </h2>
      <h1 class="mb-4 pb-0">International Conference on<br><span>Navigating global Energy transition </span>for <span>Sustainable Future</span> (ICNETS 2024)</h1>  
      <p class="mb-4 pb-0"> <i class="fas fa-desktop red-icon fa-lg mr-2"></i>(HYBRID MODE)</p>
      <p class="mb-4 pb-0"> <i class="far fa-calendar-alt red-icon fa-lg mr-2"></i>September 18<sup>th</sup>-20<sup>th</sup>, 2024</p> 
      <p class="mb-4 pb-0"><i class="fas fa-map-marker-alt red-icon fa-lg mr-2"></i>Energy Cluster, SoAE, UPES, Dehradun</p>     
      <!-- <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video"
        data-autoplay="true"></a> -->
      <a href="#buy-tickets" class="about-btn scrollto">REGISTER NOW</a>
    </div>
  </section>

  <main id="main">

    <!--==========================
      About Section
    ============================-->
    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h2>Event Highlights</h2>
            <!-- <p>Sed nam ut dolor qui repellendus iusto odit. Possimus inventore eveniet accusamus error amet eius aut
              accusantium et. Non odit consequatur repudiandae sequi ea odio molestiae. Enim possimus sunt inventore in
              est ut optio sequi unde.</p> -->
          </div>
          <div class="col-lg-3">
            <h6><i class="fas fa-star"></i>Brain Storming sessions with academic and industry stalwarts</h6>
            <h6><i class="fas fa-star"></i>Innovations and Technological advancements in CCUS</h6>
            <h6><i class="fas fa-star"></i>Panel discussion on the carbon budget</h6>
          </div>
          <div class="col-lg-3">
            <h6><i class="fas fa-star"></i>Technology demonstration from industries</h6>
            <h6><i class="fas fa-star"></i>Exhibition by school students</h6>
            <h6><i class="fas fa-star"></i>Paper/Poster Presentation</h6>
          </div>
        </div>
      </div>
    </section>

    <section id="speakers" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2 class="text-center font-weight-bold">Our Guests</h2>
          <p>Here are some of our Invited Guests</p>
        </div>
    
        <!-- Chief Guest -->
        <div class="row" style="justify-content: center;">
          <!-- <div class="col-lg-6 col-md-6"> -->
          <div class="col-lg-12 text-center">
            <h2 class="text-center font-weight-bold"><u>Chief Guest</u></h2>
          </div>
        </div>
        <!-- <div style="justify-content: center;">
        <h3>To Be Announced....!</h3>
      </div> -->
        
      <div class="row" style="justify-content: center;">
          
        <div class="col-lg-4 col-md-4">
          <!-- Speaker details for Guest of Honor -->
          <div class="speaker" >
            <div class="image-container">
              <a href="/speaker-details/12"><img loading="lazy" src="img/guest/ravi.jpg" alt="Chief Guest" class="img-fluid" style="border: solid #343a40 2px; border-radius: 10px;"></a>
            </div>
            <div class="details">
              <h3><a href="/speaker-details/12">Dr. Rabi N Bastia</a></h3>
              <p>Padmashree Awardee <br>CEO, Oilmax Energy Pvt. Ltd</p>
              
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
                
              <p></p>
              </div>
            </div>
          </div>
        </div>
      
      </div>


        <br>
    

        <div class="row">
          <div class="col-lg-12">
            <h2 class="text-center font-weight-bold"><u>Guest of Honors</u></h2>
          </div>
        </div>
    
        
        
        <!-- Guest of Honor Speakers -->
        <div class="row" style="justify-content: center;">
          
          <div class="col-lg-4 col-md-4">
            <!-- Speaker details for Guest of Honor -->
            <div class="speaker" >
              <div class="image-container">
                <a href="/speaker-details/13"><img loading="lazy" src="img/guest/nag1 (1).jpg" alt="Speaker 5" class="img-fluid" style="border: solid #343a40 2px; border-radius: 10px;"></a>
              </div>
              <div class="details">
                <h3><a href="/speaker-details/13">Dr. Kaustav Nag</a></h3>
                <p>ADG (Exploration)<br>DGH, MoPNG</p>
                
                <div class="social">
                  <!-- <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a> -->
                  
                <p></p>
                </div>
              </div>
            </div>
                        <div class="speaker" >
              <div class="image-container">
                <a href="/speaker-details/17"><img loading="lazy" src="img/guest/ravimisra.png" alt="Speaker 5" class="img-fluid" style="border: solid #343a40 2px; border-radius: 10px;"></a>
              </div>
              <div class="details">
                <h3><a href="/speaker-details/17">Dr. Ravi Misra</a></h3>
                <p>Advisor (E&P), IOCL</p>
                
                <div class="social">
                  <!-- <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a> -->
                  
                <p></p>
                </div>
              </div>
            </div>
          </div>
         
      </div>
    </section>
  <section id="important-dates">
    <div class="section-header">
      <h2>IMPORTANT DATES</h2>
      <!-- <p>Follow the deadlines strictly</p> -->
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <table class="table table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>Event</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Abstract submission deadline</td>
                            <td>Close</td>
                        </tr>
                        <tr>
                            <td>Last Date of Acceptance</td>
                            <td>Close</td>
                        </tr>
                        <tr>
                            <td>Registration Deadline</td>
                            <td>13/09/2024</td>
                        </tr>
                        <tr>
                            <td>Early Bird Registration ends</td>
                            <td>Close</td>
                        </tr>
                    </tbody>
                </table>
                <p class="text-center"><span style="color: red;">*</span>Spot Registration is available with an extra amount of 500 INR</p>
            </div>
        </div>
    </div>
</section>

    <section id="schedule" class="section-with-bg">
      <div class="container wow fadeInUp">
        <div class="section-header">
          <h2>Event Schedule</h2>
          <!-- <p>Here is our event schedule</p> -->
        </div>

        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Day 1</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#day-2" role="tab" data-toggle="tab">Day 2</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#day-3" role="tab" data-toggle="tab">Day 3</a>
          </li>
        </ul>

        <div class="tab-content row justify-content-center">

          <!-- Schdule Day 1 -->
          <div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">

            <div class="row schedule-item">
              <div class="col-md-2"><time>09:00AM - 10:00AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/1.jpg" alt="Brenden Legros"> -->
                   <!-- <img src="img/icons/two.png" />-->

                </div>
                <h4>Registration</h4>                 <!-- <p>Fugit voluptas iusto maiores temporibus autem numquam magnam.</p> -->
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>10:00AM - 11:30AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/1.jpg" alt="Brenden Legros"> -->
                   <!-- <img src="img/icons/two.png" />-->

                </div>
                <h4>Inaugural Ceremony</h4>
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>11:30AM - 12:00PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/2.jpg" alt="Hubert Hirthe"> -->
                   <!-- <img src="img/icons/two.png" />-->

                </div>
                <h4>High Tea</h4>
                <!-- <p>Maiores dignissimos neque qui cum accusantium ut sit sint inventore.</p> -->
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>12:00PM - 01:00PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/20"><img loading="lazy" src="img/speakers/bagchi.jpg" alt="Speaker"></a>
                </div>
                <h4>Invited Talk 1 </h4>
                <h4><em>Invited Talk by</em><a href="/speaker-details/20"> Ms Nebula Bagchi</a></h4>
                <!-- <h4></h4> -->
                <!-- <span>Title: "TBD"<em></em></span></h4> -->
                <!-- <p>Veniam accusantium laborum nihil eos eaque accusantium aspernatur.</p> -->
              </div>
              <div class="col-md-2"></div>

              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/19"><img loading="lazy" src="img/speakers/rsrawat.jpg" alt="Speaker"></a>
                </div>
                <h4>Invited Talk 2 </h4>
                <h4><em>Invited Talk by</em> <a href="/speaker-details/19">Dr. RS Rawat</a>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>01:00PM - 02:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/4.jpg" alt="Jack Christiansen"> -->
                </div>
                <h4>Lunch</h4>
                <!-- <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p> -->
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>02:00PM - 03:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/4"><img loading="lazy" src="img/speakers/Dr. Vikram vishal.JPG" alt="Speaker"></a>
                </div>
               
                <h4>Invited Talk 3 </h4>
                <h4><em>Invited Talk by</em> <a href="/speaker-details/4">Dr. Vikram Vishal</h4></a>
              </div>
            </div>
            <div class="row schedule-item">
              <div class="col-md-2"><time>03:00PM - 03:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                </div>
                <h4>High Tea</h4>
              </div>
            </div>
            <div class="row schedule-item">
              <div class="col-md-2"><time>03:30PM - 04:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                </div>
                <h4>Technical Session 1</h4>
              </div>
            </div>
            <div class="row schedule-item">
              <div class="col-md-2"><time>04:30PM - 05:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                </div>
                <h4>Technical Session 2</h4>
              </div>
            </div>

          </div>
          <!-- End Schdule Day 1 -->

          <!-- Schdule Day 2 -->
          <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-2">

            <div class="row schedule-item">
              <div class="col-md-2"><time>09:30AM - 11:00AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/21"><img loading="lazy" src="img/speakers/arun kumar singhal.jfif" alt="Speaker"></a>
                </div>
                <h4>Invited Talk 4</h4>
                <h4><em>Invited Talk by</em> <a href="/speaker-details/21">Mr. Arun Kumar Singhal</h4></a>
                <!-- <h4> <span><em>Title: "TBD"</em></span></h4> -->
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
              </div>
              <div class="col-md-2"></div>
              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/9"><img loading="lazy" src="img/speakers/Rakesh Photo.jpg" alt="Speaker"></a>
                </div>
                <h4>Invited Talk 5</h4>
                <h4><em>Invited Talk by</em> <a href="/speaker-details/9">Mr. Rakesh Vankayla</h4></a>
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
              </div>
              <div class="col-md-2"></div>
             
            </div>

            

            <div class="row schedule-item">
              <div class="col-md-2"><time>11:00AM - 11:30AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/3.jpg" alt="Cole Emmerich"> -->
                </div>
                <h4>High Tea</h4>
                <!-- <p>Veniam accusantium laborum nihil eos eaque accusantium aspernatur.</p> -->
              </div>
            </div>

          


            <div class="row schedule-item">
              <div class="col-md-2"><time>11:30AM - 12:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/4.jpg" alt="Jack Christiansen"> -->
                </div>
                <h4>Panel Discussion</h4>
                <h4><em>Our Panelists are</em></h4>
                <div class="speaker">
                  <a href="/speaker-details/4"><img loading="lazy" src="img/speakers/Dr. Vikram vishal.JPG" alt="Panelist 1"></a>
                  
                </div>
                <div class="speaker">
                  <a href="/speaker-details/8"><img loading="lazy" src="img/speakers/Mr. Debabrata Tripathy.jpg" alt="Panelist 2"></a>
                  
                </div>
                <div class="speaker">
                  <a href="/speaker-details/10"><img loading="lazy" src="img/speakers/Purushottam uniyal.png" alt="Panelist 3"></a>
                  
                </div>
                <div class="speaker">
                  <a href="/speaker-details/11"><img loading="lazy" src="img/speakers/Dr. Rajesh Tripathi_sir.jpg" alt="Panelist 4"></a>
                  
                </div>
                <!-- <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p> -->
              </div>
            </div>
              <div class="row schedule-item">
              <div class="col-md-2"><time>12:30PM - 01:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/6.jpg" alt="Willow Trantow"> -->
                </div>
                <h4>Poster Presentation</h4>
                <!-- <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p> -->
              </div>
            </div>
             <div class="row schedule-item">
              <div class="col-md-2"><time>01:30PM - 02:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/5.jpg" alt="Alejandrin Littel"> -->
                </div>
                <h4>Lunch</h4>
                <!-- <p>Eligendi quo eveniet est nobis et ad temporibus odio quo.</p> -->
              </div>
            </div>
            <div class="row schedule-item">
              <div class="col-md-2"><time>02:30PM - 03:30PM</time></div>
                <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/7"><img loading="lazy" src="img/speakers/Dr. Pratik Dutta.jpg" alt="Speaker"></a>
                </div>
                <h4>Invited Talk 6</h4>
                <h4><em>Invited Talk by</em>  <a href="/speaker-details/7">Dr. Pratik Dutta</h4></a>
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
              </div>
              <div class="col-md-2"></div>
              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/14"><img loading="lazy" src="img/speakers/debasis.jpg" alt="Speaker"></a>
                </div>
                <h4>Invited Talk 7</h4>
                <h4><em>Invited Talk by</em> <a href="/speaker-details/14">Dr. Debasis Das</h4></a>
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
              </div>
            </div>
            <div class="row schedule-item">
              <div class="col-md-2"><time>03:30PM - 04:00PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/6.jpg" alt="Willow Trantow"> -->
                </div>
                <h4>High Tea</h4>
                <!-- <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p> -->
              </div>
            </div>
              <div class="row schedule-item">
              <div class="col-md-2"><time>04:00PM - 04:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/16"><img loading="lazy" src="img/speakers/16.jpg" alt="speaker"></a>
                </div>
                <h4>Invited Talk 8</h4>
                <h4><em>Invited Talk by</em> <a href="/speaker-details/16">Dr. Ajay K. Ray </h4></a>
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
              </div>
            </div>
            <div class="row schedule-item">
              <div class="col-md-2"><time>04:30PM - 05:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/6.jpg" alt="Willow Trantow"> -->
                </div>
                <h4>Technical Session 3</h4>
                <!-- <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p> -->
              </div>
            </div>

          </div>
          <!-- End Schdule Day 2 -->

          <!-- Schdule Day 3 -->
          <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-3">

            <div class="row schedule-item">
              <div class="col-md-2"><time>09:30AM - 12:00PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/1"><img loading="lazy" src="img/speakers/Dr. Hemantha S..png" alt="speaker"></a>
                </div>
                <h4>Invited Talk 9</h4>
                <h4><em>Invited Talk by</em> <a href="/speaker-details/1">Dr. Hemanta Sarma</h4></a>
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
              </div>
              <div class="col-md-2"></div>
              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/15"><img loading="lazy" src="img/speakers/rajkumar.jpg" alt="speaker"></a>
                </div>
                <h4>Invited Talk 10</h4>
                <h4><em>Invited Talk by</em> <a href="/speaker-details/15">Dr. Raj Kumar Arya</h4></a>
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
            </div>
              <div class="col-md-2"></div>
              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/6"><img loading="lazy" src="img/speakers/amit.jpg" alt="speaker"></a>
                </div>
                <h4>Invited Talk 11</h4>
                <h4><em>Invited Talk by</em> <a href="/speaker-details/6">Dr. Amit Kumar</h4></a>
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
              </div>
               <div class="col-md-2"></div>
              <div class="col-md-10">
                <div class="speaker">
                  <a href="/speaker-details/2"><img loading="lazy" src="img/speakers/Dr.%20james%20Peters.jpg" alt="speaker"></a>
                </div>
                <h4>Invited Talk 12</h4>
                <h4><em>Invited Talk by</em> <a href="/speaker-details/2">Dr. James Peters</h4></a>
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
              </div>
            </div>

            

            <div class="row schedule-item">
              <div class="col-md-2"><time>12:00PM - 12:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/1.jpg" alt="Brenden Legros"> -->
                </div>
                <h4>High Tea</h4>
                <!-- <p>Facere provident incidunt quos voluptas.</p> -->
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>12:30PM - 01:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/4.jpg" alt="Jack Christiansen"> -->
                </div>
                <h4><a href="/documents/school_event.pdf" download>School Event</a></h4>
                <!-- <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p> -->
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>01:30PM - 02:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/5.jpg" alt="Alejandrin Littel"> -->
                </div>
                <h4>Lunch</h4>
                <!-- <p>Eligendi quo eveniet est nobis et ad temporibus odio quo.</p> -->
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>02:30PM - 03:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/6.jpg" alt="Willow Trantow"> -->
                </div>
                <h4>Technical Session 4</h4>
                <!-- <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p> -->
              </div>
            </div>
            <div class="row schedule-item">
              <div class="col-md-2"><time>03:30PM - 04:00PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/speakers/6.jpg" alt="Willow Trantow"> -->
                </div>
                <h4>High Tea </h4>
                <!-- <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p> -->
              </div>
            </div>
            <div class="row schedule-item">
              <div class="col-md-2"><time>04:00PM - 05:30PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <!-- <img loading="lazy" src="img/u_logo.png
                  " alt="Willow Trantow"> -->
                </div>
                <h4>Valedictory</h4>
                <!-- <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p> -->
              </div>
            </div>


          </div>
          <!-- End Schdule Day 2 -->

        </div>

      </div>

    </section>

<!-- call for paper -->



    <section id="callforpaper">
      <div class="container">
        <div class="section-header">
          <h2>Call for Paper</h2>
          <p>Submit your paper</p>
        </div>
        <div class="row">
          <div class="col-lg-4 bordered-column">
              <h2 class="justify-content-center">Guidelines</h2>
              <!-- <a href="path_to_your_abstract_template_file.docx" class="btn btn-primary btn-lg">Download Guidelines</a> -->
          </div>
          <div class="col-lg-4 bordered-column">
              <h3>Abstract Submission</h3>
              <a href="./documents/Abstract Submission Guidelines.pdf" class="btn btn-primary btn-lg">Download</a>
          </div>
          <div class="col-lg-4 bordered-column">
              <h3>Poster Submission</h3>
              <a href="./documents/Poster Submission Guidelines.pdf" class="btn btn-primary btn-lg">Download</a>
          </div>
      </div>
      <div class="row">
        <div class="col-lg-4 bordered-column">
            <h2 class="justify-content-center">Templates</h2>
            <!-- <a href="path_to_your_abstract_template_file.docx" class="btn btn-primary btn-lg">Download Guidelines</a> -->
        </div>
        <div class="col-lg-4 bordered-column">
            <h3>Abstract Submission</h3>
            <a href="./documents/Abstract Template.docx" class="btn btn-primary btn-lg">Download</a>
        </div>
        <div class="col-lg-4 bordered-column">
            <h3>Presentation (Poster/Oral)</h3>
            <a href="./documents/ICNETS-2024(Poster Template).pptx" class="btn btn-primary btn-lg">Download Poster</a>
             <a href="./documents/Oral Presentation template.pptx" class="btn btn-primary btn-lg">Download Oral</a>
        </div>
    </div>
      </div id="registerbtn">
        <!--<div class="row justify-content-center">
          <div style="padding-top: 20px";class="col-lg-6 text-center">
              <a href="https://docs.google.com/forms/d/e/1FAIpQLSdBLabYMUSVPg-doCr8QBOSxQO_l4WQbmnzZxf7_aEe9AcxIg/viewform?usp=sf_link" class="btn btn-primary btn-lg">CLICK HERE FOR REGISTRATION</a>
          </div>-->
        </div id="registerbtn">
        <div class="row justify-content-center">
          <div style="padding-top: 20px";class="col-lg-6 text-center">
              <a href="https://docs.google.com/forms/d/e/1FAIpQLSeDkIqAbhQoNMReZhoU5pFeQyrUwp0DvbTWeyFlLKgcp8z2_Q/viewform?usp=sf_link" class="btn btn-primary btn-lg">CLICK HERE FOR ABSTRACT SUBMISSION</a>
          </div>
          
          
      </div>
      <div class="row justify-content-center">
          <div style="padding-top: 20px";class="col-lg-6 text-center">
             <a href="/documents/school_event.pdf" download class="btn btn-primary btn-lg">Click Here For School Event Registration</a>
          </div>
      </div>
      <style>
            .flex-container {
              display: flex;
              flex-direction: row;
              width:100%;
                justify-content: center;
                flex-wrap: wrap;
                margin: 20px;
                gap: 20px 20px;
            }

            /* Responsive layout - makes a one column layout instead of a two-column layout */
            @media (max-width: 800px) {
              .flex-container {
                flex-direction: column;
              }
            }
      </style>
     <div class="container py-2">
        <div class="section-header">
          <p>Our Publishing Partner</p>
        </div>
        <div class="flex-container" style="">
            <div style="width:300px; min-height: 400px;" class="row justify-content-center mx-2">
          <div class="">
            <div class="card">
              <center><img src="/img/15.jpeg" width="300px" height="300px" alt="Discover Applied Sciences"></center>
              <div class="card-body">
                <h5 class="card-title text-center" style="font-size:20px;">Biomass Conversion And Biorefinery</h5>
                 <center><p style="font-size:14px; max-width:300px; ">
                     Impact factor 3.5<br/>
                     SCIE 
                 </p></center>
                                  <br/>
                                                                    <br/>



              </div>
            </div>
          </div>
        </div>
        <div style="width:300px; min-height: 400px;" class="row justify-content-center mx-2">
          <div class="">
            <div class="card">
              <center><img src="/img/newimage.png" width="300px" height="300px" alt="Discover Applied Sciences"></center>
              <div class="card-body">
                <h5 class="card-title text-center" style="font-size:20px;">International Journal of Chemical Reactor Engineering</h5>
                 <center><p style="font-size:14px; max-width:300px; ">
                     Impact Factor:1.2<br/>
                     SCIE And Scopus 
                 </p></center>
                                  <br/>


              </div>
            </div>
          </div>
        </div>
        
        <div style="width:300px; min-height: 400px;" class="row justify-content-center mx-2">
          <div class="">
            <div  class="card">
              <img src="/img/image.png" class="card-img-top img-fluid" width="300px" height="400px" alt="Discover Applied Sciences">
              <div class="card-body">
                <h5 class="card-title text-center">Discover Applied Sciences</h5>
                 <center><p style="font-size:14px; max-width:300px;">
                     Scopus
                 </p></center>



              </div>
            </div>
          </div>
        </div>
        <div style="width:300px; min-height: 400px;" class="row justify-content-center mx-2">
          <div class="">
            <div  class="card">
              <img src="/img/bulgarianc.jpg" class="card-img-top img-fluid" width="300px" height="400px" alt="Bulgarian Chemical Communications">
              <div class="card-body">
                <h5 class="card-title text-center">Bulgarian Chemical Communications</h5>
                 <center><p style="font-size:14px; max-width:300px;">
                     Scopus
                 </p></center>
                 <br/>
                <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
              </div>
            </div>
          </div>
        </div>
         <div style="width:300px; min-height: 400px;" class="row justify-content-center mx-2">
          <div class="">
            <div class="card">
              <img src="/img/unnamed.jpg" class="card-img-top img-fluid" width="300px" height="400px" alt="Discover Applied Sciences">
              <div class="card-body">
                <h5 class="card-title text-center">Springer Nature</h5>
                <p style="font-size:8.5px; max-width:300px; text-align:justify;">It is planned to publish the peer reviewed and selected papers of conference as proceedings with Springer in their prestigious “Lecture Notes in Electrical Engineering” series (<a href="https://www.springer.com/series/7818">https://www.springer.com/series/7818</a>). For detailed instructions for author and editors of conference proceedings, kindly visit the following link: <a href="https://www.springer.com/us/authors-editors/conference-proceedings">https://www.springer.com/us/authors-editors/conference-proceedings</a>. Select papers from the conference will be published by Springer as a proceedings book volume. Springer will conduct quality checks on the accepted papers and only papers that pass these checks will be published. Springer Nature does not charge any money for publication of Non-Open Access content. Abstracts/extended abstracts and short papers (less than 4 pages) are not considered for publication.</p>
                <p style="font-size: 11px;">Book Name: Global Energy Transition and Sustainable Development Challenges<br/>
                    ISBN Number: 978-81-967868-6-1
                </p>
              </div>
            </div>
          </div>
        </div>
        </div>
      </div>
      
    </section>

<br/>
<br/>
<br/>
    <!-- themes -->

    <!--==========================
      F.A.Q Section
    ============================-->
    <section id="faq" class="wow fadeInUp">

      <div class="container">

        <div class="section-header">
          <h2>Themes</h2>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-9">
              <ul id="faq-list">

                <li>
            <a data-toggle="collapse" class="collapsed" href="#faq1"><strong>Carbon Capture, Utilization, and Storage (CCUS)</strong> <i class="fa fa-minus-circle"></i></a>
            <div id="faq1" class="collapse" data-parent="#faq-list">
              <ul style="list-style-type: square;">
                <li>Climate Crisis</li>
                <li>Technological Advancements in Carbon Capture</li>
                <li>Life Cycle Assessment of CCUS Projects</li>
                <li>CO<sub>2</sub> Transportation and Infrastructure</li>
                <li>Carbon Capture Readiness (CCR)</li>
                <li>Storage sites</li>
                <li>Risk Assessment and recourse measures</li>
                <li>Public perception and social acceptance.</li>
              </ul>
            </div>
          </li>
      
                <li>
                  <a data-toggle="collapse" href="#faq2" class="collapsed"><strong>Smart Grid and Energy Storage </strong><i class="fa fa-minus-circle"></i></a>
                  <div id="faq2" class="collapse" data-parent="#faq-list">
                    <ul style="list-style-type: square;">
                      <li>Flow Batteries</li>
                      <li>Materials for Energy Storage</li>
                      <li>Grid Resilience and Reliability</li>
                      <li>Energy Storage Integration with Generation and Consumption</li>
                      <li>Market Dynamics and Energy Storage</li>
                      <li>Energy scavenging</li>
                      <li>AI in Energy Storage</li>
                      <li>Urban Energy System</li>
                  </ul>
                  </div>
                </li>
                <!--<li>
                  <a data-toggle="collapse" href="#faq3" class="collapsed"><strong>Advacnce Materials in Decarbonisation</strong> <i class="fa fa-minus-circle"></i></a>
                  <div id="faq3" class="collapse" data-parent="#faq-list">
                    <ul style="list-style-type: square;">
                      <li>Advanced Materials in Energy domain</li>
                      <li>Solar cell Materials</li>
                      <li>Low cost materials for energy Storage</li>
                      <li>Smart materials in Energy domain</li>
                    </ul>
                  </div>
                </li>-->
                <li>
                  <a data-toggle="collapse" href="#faq3" class="collapsed"><strong>Green Energy production, conversion, and utilization</strong> <i class="fa fa-minus-circle"></i></a>
                  <div id="faq3" class="collapse" data-parent="#faq-list">
                    <ul style="list-style-type: square;">
                      <li>Community-centered clean energy transition</li>
                      <li>Hydrogen Supply Chain; Production, Storage and Distribution, Consumption and Application</li>
                      <li>Innovations in clean energy</li>
                      <li>Renewable Energy Integration</li>
                      <li>Sustainable Sourcing of Biomass</li>
                      <li>Global Bioenergy Potential</li>
                      <li>3Bs (Biofuels, Bioresources, and Bioengineering)</li>
                      <li>Technological challenges in renewable energy adoption</li>
                  </ul>
                  </div>
                </li>
      
                <li>
                  <a data-toggle="collapse" href="#faq4" class="collapsed"><strong>Circular Economy in Energy</strong> <i class="fa fa-minus-circle"></i></a>
                  <div id="faq4" class="collapse" data-parent="#faq-list">
                    <ul style="list-style-type: square;">
                      <li>Green energy infrastructure</li>
                      <li>Net-zero future and energy efficiency</li>
                      <li>Smart Buildings, and cities</li>
                      <li>Blue Economy</li>
                      <li>5Rs: Refuse, Reform, Reduce, Reuse, and Recycle</li>
                      <li>Waste to energy technologies.</li>
                  </ul>
                  </div>
                </li>
      
                <li>
                  <a data-toggle="collapse" href="#faq5" class="collapsed"><strong>Digitalization for Sustainability</strong> <i class="fa fa-minus-circle"></i></a>
                  <div id="faq5" class="collapse" data-parent="#faq-list">
                    <ul style="list-style-type: square;">
                      <li>AI for energy sustainability</li>
                      <li>Geoinformatics and Big Data in Energy Transition</li>
                      <li>Geomatics in Oil & Gas Industry</li>
                      <li>SCADA and Energy Security</li>
                      <li>Cybersecurity/ blockchain technology in Energy infrastructure</li>
                      <li>Digital Twin in Energy Space</li>
                      <li>UAVs in Oil and Gas</li>
                      <li>Role of technology in decarbonization (IOT/IIOT, Industry 4.0/5.0, 5G, Cyber Security)</li>
                    </ul>
                  </div>
                </li>
      
                <li>
                  <a data-toggle="collapse" href="#faq6" class="collapsed"><strong>Economic Opportunities in Decarbonization </strong><i class="fa fa-minus-circle"></i></a>
                  <div id="faq6" class="collapse" data-parent="#faq-list">
                    <ul style="list-style-type: square;">
                      <li>Sustainable Businesses and Job Opportunities</li>
                      <li>E-Mobility and Sustainable Fuels</li>
                      <li>Decarbonizing the Hard to Abate Sectors</li>
                      <li>Green Materials</li>
                  </ul>
          
                  </div>
                </li>

                <li>
                  <a data-toggle="collapse" href="#faq7" class="collapsed"><strong>Carbon Trading and its Environmental Impacts</strong> <i class="fa fa-minus-circle"></i></a>
                  <div id="faq7" class="collapse" data-parent="#faq-list">
                    <ul style="list-style-type: square;">
                      <li>Green Economy Finance</li>
                      <li>Energy simulation and carbon markets</li>
                      <li>Social Cost of Carbon</li>
                      <li>Regulations and Standards in Carbon Trading</li>
                      <li>The role of carbon markets in reducing GHG emissions</li>
                      <li>Compliance and Voluntary Carbon Markets</li>
                      <li>Importance and Opportunities for Nature Based Solutions in Carbon Trading Market.</li>
                      <li>Carbon Credit Marketplace and Trading Platforms</li>
                  </ul>
          
                  </div>
                </li>

                <li>
                  <a data-toggle="collapse" href="#faq8" class="collapsed"><strong>Policy Framework and Regulations for Climate-Positive Earth</strong> <i class="fa fa-minus-circle"></i></a>
                  <div id="faq8" class="collapse" data-parent="#faq-list">
                    <ul style="list-style-type: square;">
                      <li>Energy Subsidy</li>
                      <li>Social Impacts of Clean Energy Policies</li>
                      <li>Legal and Ethical Consideration of Energy Transition</li>
                      <li>Economy and Emission</li>
                      <li>Policy barriers in Net zero goals</li>
                  </ul>
          
                  </div>
                </li>
      

                <li>
                  <a data-toggle="collapse" href="#faq9" class="collapsed"><strong>Conventional and Unconventional Energy Resources</strong> <i class="fa fa-minus-circle"></i></a>
                  <div id="faq9" class="collapse" data-parent="#faq-list">
                    <ul style="list-style-type: square;">
                      <li>Global Energy Crisis and Reduction in Methane Emission</li>
                      <li>Flow Assurance: Wax Deposition, Asphaltene Deposition, etc.</li>
                      <li>Enhanced Oil Recovery/Enhanced Gas Recovery and CCUS</li>
                      <li>Advancements in Nanotechnology in Oil and Gas</li>
                      <li>Recent Advancements in Oil and Gas Transportation</li>
                      <li>CBM, Shale gas, Tight gas, and Gas hydrates</li>
                      <li>Life cycle of oil and gas fields, Operational Excellence, Marginal Oilfields Development.</li>
                      <li>Modelling and Simulation of Petroleum Processes</li>
                      <li>Oilfield operations and Product Developments</li>
                      <li>Safety and Risk Management in the Oil and Gas Sector</li>
                      <li>Corporate Responsibility in Environmental Production</li>
                      <li>Formation Damage Control</li>
                      <!-- <li>AI Applications in Petroleum Industry</li> -->
                      <li>Offshore Technologies</li>
                      <li>Technological innovations in fossil fuel extraction</li>
                      <li>Workforce Diversity and Development Strategies</li>
                  </ul>
          
                  </div>
                </li>

                <li>
                  <a data-toggle="collapse" href="#faq10" class="collapsed"><strong>Geo-resilience, Enviroment and, Sustainability </strong><i class="fa fa-minus-circle"></i></a>
                  <div id="faq10" class="collapse" data-parent="#faq-list">
                      <ul style="list-style-type: square;">
                          <li>Natural hazard and disaster</li>
                          <!-- <li>Natural Disasters</li> -->
                          <li>Risk assessment and management</li>
                          <li>Climate Resilience</li>
                          <li>Geopolitical risk and energy security</li>
                        <li>Natural resources and pollution</li>
                        <li>Sustainable agriculture and food security</li>
                        <li>Enviromental Integrity - atomosphere, biosphere, hydrosphere and, lithosphere</li>
                        <li>Health, safety and, enviroment</li>
                        <li>Geo-tourism</li>
                        
                      </ul>
                  </div>
              </li>
              
      
              </ul>
          </div>
        </div>

      </div>

    </section>

    <!-- themes end.. -->


    <!--==========================
      Gallery Section
    ============================-->
    <section id="gallery" class="wow fadeInUp">

      <div class="container">
        <div class="section-header">
          <h2>Gallery</h2>
          <p>Check our gallery from the recent events</p>
        </div>
      </div>

      <div class="owl-carousel gallery-carousel">
        <a href="img/gallery/_DSC0446.JPG" class="venobox" data-gall="gallery-carousel" data-vb-width="200" data-vb-height="200"><img loading="lazy" src="img/gallery/_DSC0446.JPG" alt=""></a>
        <a href="img/gallery/_DSC8058 (1).JPG" class="venobox" data-gall="gallery-carousel"><img loading="lazy" src="img/gallery/_DSC8058 (1).JPG" alt=""></a>
        <a href="img/gallery/_DSC8371.JPG" class="venobox" data-gall="gallery-carousel"><img loading="lazy" src="img/gallery/_DSC8371.JPG" alt=""></a>
        <a href="img/gallery/campus-image.jpg" class="venobox" data-gall="gallery-carousel"><img loading="lazy" src="img/gallery/campus-image.jpg" alt=""></a>
        <a href="img/gallery/IMG_2990.JPG" class="venobox" data-gall="gallery-carousel"><img loading="lazy" src="img/gallery/IMG_2990.JPG" alt=""></a>
        <a href="img/gallery/IMG_2998.JPG" class="venobox" data-gall="gallery-carousel"><img loading="lazy" src="img/gallery/IMG_2998.JPG" alt=""></a>
        <!-- <a href="img/gallery/IMG_3023.JPG" class="venobox" data-gall="gallery-carousel"><img loading="lazy" src="img/gallery/IMG_3023.JPG" alt=""></a> -->
        <a href="img/gallery/IMG_3129 (1).JPG" class="venobox" data-gall="gallery-carousel"><img loading="lazy" src="img/gallery/IMG_3129 (1).JPG" alt=""></a>
      </div>

    </section>

    <!--==========================
      Sponsors Section
    ============================-->
    <section id="supporters" class="section-with-bg wow fadeInUp">

      <div class="container">
        <div class="section-header">
          <h2>Sponsors</h2>
        </div>

        <div class="row no-gutters supporters-wrap clearfix">
            <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/ongc.jpg" class="img-fluid" alt="" style="object-fit: contain; width: 100%; height: 100%;">
            </div>
          </div>
         
          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/SKP Logo.jpg" class="img-fluid" alt="">
            </div>
          </div>
           <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/vardhman.jpg" class="img-fluid" alt="">
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/heliware.png" class="img-fluid" alt="">
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/ACSPubs_logo_tagline_CMYK.jpg" class="img-fluid" alt="">
            </div>
          </div>
            <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/PHOTO-2024-08-24-00-30-30.jpg" class="img-fluid" alt="">
            </div>
          </div>
            <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/srl.jpg" class="img-fluid" alt="">
            </div>
          </div>
          <!--
           
        
          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/image (7).png" class="img-fluid" alt="">
            </div>
          </div>
          
          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/LOGO ECOSENSE.PNG" class="img-fluid" alt="">
            </div>
          </div>
          
          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/replicate-prediction-do4dcazbtppcfccmn2b6boitvi.png" width="75%" height="75%" img-fluid" alt="">
            </div>
          </div>
        
          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/RSC_logo_POS_RGB_L.jpg" class="img-fluid" alt="">
            </div>
          </div>
          
         
          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img loading="lazy" src="img/supporters/waters-ta-logo-color.png" class="img-fluid" alt="">
            </div>
          </div>
          
-->
        </div>

      </div>

    </section>
  
    <section id="buy-tickets" class="section-with-bg wow fadeInUp">
      <div class="container">

        <div class="section-header">
          <h2>Registration</h2>
          <p>Check your plans and register below</p>
        </div>

        <style>
          .table-responsive {
              overflow-x: auto;
          }
          table {
              width: 100%;
              border-collapse: collapse;
          }
          th, td {
              padding: 8px;
              text-align: left;
              border-bottom: 1px solid #ddd;
          }
          @media only screen and (max-width: 600px) {
              th, td {
                  font-size: 8.5px;
                  white-space: nowrap; /* Prevent line breaks */
                  text-decoration: solid;
              }
          }
      </style>
      
<div id="table-responsive">
<table class="table table-striped">
    <thead class="thead-dark">
        <tr>
            <th>Category</th>
            <th>Early Bird</th>
            <th>Regular</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Academician/Scholars/Students (With Publication)</td>
            <td>5000 INR</td>
            <td>6000 INR</td>
        </tr>
        <tr>
            <td>Academician/Scholars/Students (Without Publication)</td>
            <td>2500 INR</td>
            <td>2500 INR</td>
        </tr>
        <tr>
            <td>Industry Delegates/Corporate/Entrepreneurs</td>
            <td>7000 INR</td>
            <td>8000 INR</td>
        </tr>
        <tr>
            <td>Foreign Participants</td>
            <td>120 USD</td>
            <td>150 USD</td>
        </tr>
        <tr>
          <td>Accompanying Person/Attendee</td>
          <td colspan="2" style="text-align: center;">1500 INR</td>
      </tr>
      
    </tbody>
    
</table>
<p class="text-center"><span style="color: red;">**</span> Publication is subject to quality of work and at the sole discretion of publisher.</p>
</div>
<br>

  <div class="text-center"><h3 style="text-decoration: underline;"> <strong>Banking Details</strong></h3>
  </div>
        <div class="row justify-content-center equal-height-cards">
          <style>
            .equal-height-cards {
  display: flex;
  justify-content: space-between;
}

.col-lg-4 {
  flex: 1;
}

.card-body {
  height: 100%;
}
.equal-height-cards {
  display: flex;
  justify-content: space-between;
}

.col-lg-4 {
  flex: 1;
}

.card-body {
  height: 100%;
}

.national-card .card-body {
  /* min-height: 560px; Adjust the height as needed */
}


          
          </style>
          <div class="col-lg-6">
            <div class="card mb-5 mb-lg-0 national-card">
              <div class="card-body ">
                <h4 class="card-title text-muted text-uppercase text-center">NATIONAL PARTICIPANTS</h4>
                <!-- <h6 class="card-price text-center">$150</h6> -->
                <hr>
                <!-- <ul class="fa-ul">
                  <li>Regular Seating</li>
                  <li>Coffee Break</li>
                  <li>Custom Badge</li>
                  <li>Community Access</li>
                  <li>Workshop Access</li>
                  <li>After Party</li>
                </ul> -->
                <table>
                  <tr>
                    <td>Beneficiary Name :</td>
                    <td>ENERGY SUMMIT</td>
                  </tr>
                  <tr>
                    <td>Account Number :</td>
                    <td>UPESUK877777853</td>
                  </tr>
                  <tr>
                    <td>IFSC number :</td>
                    <td>YESB0CMSNOC</td>
                  </tr>
                  <tr>
                    <td>Bank name :</td>
                    <td>Yes Bank Ltd. </td>
                  </tr>
                  <tr>
                    <td>Address :</td>
                    <td>IFC 8TH FLOOR SB MARG MUMBAI</td>
                  </tr>
                  <tr >
                    <td colspan="2"><span style="color: red;">**</span>No UPI/IMPS is allowed, only net banking is allowed</td>
                  </tr>
                </table>
                <!-- <hr> -->
                <!-- <div class="text-center">
                  <button type="button" class="btn" data-toggle="modal" data-target="#buy-ticket-modal" data-ticket-type="standard-access">Buy Now</button>
                </div> -->
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="card mb-5 mb-lg-0">
              <div class="card-body">
                <h4 class="card-title text-muted text-uppercase text-center">INTERNATIONAL PARTICIPANTS</h4>
                <!-- <h6 class="card-price text-center">$250</h6> -->
                <hr>
                <!-- <ul class="fa-ul">
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Regular Seating</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Coffee Break</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Custom Badge</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Community Access</li>
                  <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>Workshop Access</li>
                  <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>After Party</li>
                </ul> -->
                <table>
                  <tr>
                    <td>Beneficiary Name:</td>
                    <td>University of Petroleum and Energy Studies</td>
                  </tr>
                  <tr>
                    <td>Purpose :</td>
                    <td>ENERGY SUMMIT</td>
                  </tr>
                  <tr>
                    <td>Bank Name :</td>
                    <td>Yes Bank</td>
                  </tr>
                  <tr>
                    <td>Bank Account :</td>
                    <td>SB – 011594600000224</td>
                  </tr>
                  <tr>
                    <td>Branch Code :</td>
                    <td>000115</td>
                  </tr>
                  <tr>
                    <td>Branch IFSC Code:</td>
                    <td>YESB0000115</td>
                  </tr>
                  <tr>
                    <td>Swift Code :</td>
                    <td>YESBINBB</td>
                  </tr>
                  <tr>
                    <td>Branch Name :</td>
                    <td>Ground Floor, 56, Rajpur Road,  Dehradun</td>
                  </tr>
                  <tr >
                    <td colspan="2"><span style="color: red;">**</span>No UPI/IMPS is allowed, only net banking is allowed</td>
                  </tr>
                </table>
                <!-- <hr> -->
                <!-- <div class="text-center">
                  <button type="button" class="btn" data-toggle="modal" data-target="#buy-ticket-modal" data-ticket-type="pro-access">Buy Now</button>
                </div> -->
              </div>
            </div>
          </div>
        </div>
          
          
       
          </div id="registerbtn">
        <div class="row justify-content-center">
          <div style="padding-top: 20px";class="col-lg-6 text-center">
              <a href="https://docs.google.com/forms/d/e/1FAIpQLSdBLabYMUSVPg-doCr8QBOSxQO_l4WQbmnzZxf7_aEe9AcxIg/viewform?usp=sf_link" class="btn btn-primary btn-lg">CLICK HERE FOR REGISTRATION</a>
          </div>
        </div id="registerbtn">
        <!--<div class="row justify-content-center">
          <div style="padding-top: 20px";class="col-lg-6 text-center">
              <a href="https://docs.google.com/forms/d/e/1FAIpQLSeDkIqAbhQoNMReZhoU5pFeQyrUwp0DvbTWeyFlLKgcp8z2_Q/viewform?usp=sf_link" class="btn btn-primary btn-lg">CLICK HERE FOR ABSTRACT SUBMISSION</a>
          </div> -->
          
          
      </div>
        
        
      

        
      </div>

      <!-- Modal Order Form -->
      <div id="buy-ticket-modal" class="modal fade">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Buy Tickets</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form method="POST" action="#">
                <div class="form-group">
                  <input type="text" class="form-control" name="your-name" placeholder="Your Name">
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="your-email" placeholder="Your Email">
                </div>
                <div class="form-group">
                  <select id="ticket-type" name="ticket-type" class="form-control" >
                    <option value="">-- Select Your Ticket Type --</option>
                    <option value="standard-access">Standard Access</option>
                    <option value="pro-access">Pro Access</option>
                    <option value="premium-access">Premium Access</option>
                  </select>
                </div>
                <div class="text-center">
                  <button type="submit" class="btn">Buy Now</button>
                </div>
              </form>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->

    </section>

    <!--==========================
      Contact Section
    ============================-->
    <section id="contact" class="section-bg wow fadeInUp">

      <div class="container">

        <div class="section-header">
          <h2>Contact Us</h2>
          <p>Feel free to contact us!</p>
        </div>

        <div class="row contact-info">
          <div class="col-md-4">
              <div class="contact-phone">
                  <i class="ion-ios-location-outline"></i>
                  <h3>Address</h3>
                  <address>UPES, Bidholi Campus, Dehradun<br>
                    P.O. Bidholi Via Premnagar, <br>
                    Dehradun-248007<br></address>
              </div>
          </div>
      
          <div class="col-md-4">
              <div class="contact-phone">
                  <i class="ion-ios-telephone-outline"></i>
                  <h3>Dr. Nirlipta P. Nayak</h3>
                  <p>Convener</p>
                  <p><a href="tel:+919761703989">+91-9761703989</a></p>
                  <p><a href="mailto:npnayak@ddn.upes.ac.in">npnayak@ddn.upes.ac.in</a></p>
              </div>
          </div>
      
          <div class="col-md-4">
              <div class="contact-phone">
                  <i class="ion-ios-telephone-outline"></i>
                  <h3>Mr. Rahul Kumar Singh</h3>
                  <p>Coordinator</p>
                  <p><a href="tel:+918765474257">+91-8765474257</a></p>
                  <p><a href="mailto:Rahulk.singh@ddn.upes.ac.in">Rahulk.singh@ddn.upes.ac.in</a></p>
              </div>
          </div>
          <div class="col-md-6">
            <div class="contact-phone">
                <i class="ion-ios-telephone-outline"></i>
                <h3>Mr. Aaditya R. Saxena</h3>
                <p>Student Coordinator</p>
                <p><a href="tel:+917575018999">+91-7575018999</a></p>
                <!-- <p><a href="mailto:info@example.com">npnayak@ddn.upes.ac.in</a></p> -->
            </div>
        </div>
    
        <div class="col-md-6">
            <div class="contact-phone">
                <i class="ion-ios-telephone-outline"></i>
                <h3>Ms. Ritika Panwar</h3>
                <p>Student Coordinator</p>
                <p><a href="tel:+918791033113">+91- 8791033113</a></p>
                <!-- <p><a href="mailto:info@example.com">rohitsharma@ddn.upes.ac.in</a></p> -->
            </div>
        </div>
      </div>
      

      <div class="form">
        <div id="sendmessage">Your message has been sent. Thank you!</div>
        <div id="errormessage"></div>
        <form id="contact-form" method="post" role="form" class="contactForm">
            <div class="form-row">
                <div class="form-group col-md-6">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 characters" required />
                    <div class="validation"></div>
                </div>
                <div class="form-group col-md-6">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" required />
                    <div class="validation"></div>
                </div>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 4 characters for the subject" required />
                <div class="validation"></div>
            </div>
            <div class="form-group">
                <textarea class="form-control" name="message" id="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message" required></textarea>
                <div class="validation"></div>
            </div>
            <div class="text-center"><button type="submit" id="submit-btn">Send Message</button></div>
        </form>
    </div>
    
    <script>
        document.getElementById('submit-btn').addEventListener('click', function() {
            let name = document.getElementById('name').value.trim();
            let email = document.getElementById('email').value.trim();
            let subject = document.getElementById('subject').value.trim();
            let message = document.getElementById('message').value.trim();
    
            if (name === '' || email === '' || subject === '' || message === '') {
                alert('Please fill in all fields.');
                return;
            }
    
            if (!validateEmail(email)) {
                alert('Please enter a valid email address.');
                return;
            }
    
            if (/\d/.test(name)) {
                alert('Name should not contain numbers.');
                return;
            }
        
            window.location.href = 'mailto:energysummit2024@ddn.upes.ac.in?subject=' + subject + '&body=' + 'Name: ' + name + '%0AEmail: ' + email + '%0AMessage: ' + message;
        });
    
        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
    </script>
    
      </div>
    </section>

  </main>

