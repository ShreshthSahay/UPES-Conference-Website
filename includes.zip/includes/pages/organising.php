<br/>
<br />
<style>
  .row-a {
    margin-left:30px;
  }
  @media only screen and (max-width: 480px) {
    .row-a {
      margin-left: 0;
    }
  }
  /* Target all images within the section with the class "speakers" */
  .speaker {
    width: 250px;
    height: 300px;
    overflow: hidden; /* Ensures that any overflow is hidden */
    border: 2px solid #f82249;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
}

.speaker img{
    width: 100%;
    height: 100%;
    object-fit: cover;
    justify-content: center;
}
.details{
  border: 2px solid rgba(0, 0, 0, 0.319);
  border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    /* margin: 0px; */
}
.row{
  align-items: center;
  justify-content: center;
}

.col,
  .col-1,
  .col-10,
  .col-11,
  .col-12,
  .col-2,
  .col-3,
  .col-4,
  .col-5,
  .col-6,
  .col-7,
  .col-8,
  .col-9,
  .col-auto,
  .col-lg,
  .col-lg-1,
  .col-lg-10,
  .col-lg-11,
  .col-lg-12,
  .col-lg-2,
  .col-lg-3,
  .col-lg-4,
  .col-lg-5,
  .col-lg-6,
  .col-lg-7,
  .col-lg-8,
  .col-lg-9,
  .col-lg-auto,
  .col-md,
  .col-md-1,
  .col-md-10,
  .col-md-11,
  .col-md-12,
  .col-md-2,
  .col-md-3,
  .col-md-4,
  .col-md-5,
  .col-md-6,
  .col-md-7,
  .col-md-8,
  .col-md-9,
  .col-md-auto,
  .col-sm,
  .col-sm-1,
  .col-sm-10,
  .col-sm-11,
  .col-sm-12,
  .col-sm-2,
  .col-sm-3,
  .col-sm-4,
  .col-sm-5,
  .col-sm-6,
  .col-sm-7,
  .col-sm-8,
  .col-sm-9,
  .col-sm-auto,
  .col-xl,
  .col-xl-1,
  .col-xl-10,
  .col-xl-11,
  .col-xl-12,
  .col-xl-2,
  .col-xl-3,
  .col-xl-4,
  .col-xl-5,
  .col-xl-6,
  .col-xl-7,
  .col-xl-8,
  .col-xl-9,
  .col-xl-auto {
    width: auto !important; /* Override width to auto */
  }


</style>

<section id="speakers" class="wow fadeInUp">
    <div class="container">
      <div class="section-header">
        <h2 class="text-center font-weight-bold">Organizing Commitee</h2>
        <!-- <p>The big brains behind the event!!</p> -->
      </div>
  
      <!-- Chief Guest -->
      <!-- <div class="row"> -->
        <!-- <div class="col-lg-6 col-md-6"> -->
        <!-- <div class="col-lg-12 text-center">
          <h2 class="text-center font-weight-bold"><u>Chief Guest</u></h2>
        </div> -->
      <!-- </div> -->
  
      <!-- Chief Guest Speakers -->
      <div class="row row-a">
        <div class="col-lg-4 col-md-4">
          <div class="speaker">
            <img loading="lazy" src="img/Faculty Images Updated/ram.webp" alt="Member" class="img-fluid">
            <div class="details">
              <h3>Dr. Ram Sharma</h3>
              <p>Vice Chancellor, UPES</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4">
          <div class="speaker">
            <img loading="lazy" src="img/Faculty Images Updated/faculty-nilanjana-banerjee.webp" alt="Member" class="img-fluid"  >
            <div class="details">
              <h3>Dr. Nilanjana Banerjee</h3>
              <p>Cluster Head,Energy Cluster, UPES</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-4">
          <div class="speaker">
            <img loading="lazy" src="img/Faculty Images Updated/Dr. Uday Bhan Sir.webp" alt="Member" class="img-fluid" style="width: 100%; height: auto">
            <div class="details">
              <h3>Dr. Uday Bhan</h3>
              <p>Program Lead</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
      </div>

      <br>


      <!-- <div class="row">
       
        <div class="col-lg-12 text-center">
          <h2 class="text-center font-weight-bold"><u>Program Lead</u></h2>
        </div>
      </div> -->
  
      <!-- Chief Guest Speakers -->
      <!-- <div class="row justify-content-center">
        <div class="col-lg-6 col-md-6">
          <div class="speaker">
            <img loading="lazy" src="img/speakers/5.webp" alt="Speaker 5" class="img-fluid">
            <div class="details">
              <h3>Dr. Udaya Bhan</h3>
              <p>Program Lead</p>
              <div class="social">
                <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a>
              </div>
            </div>
          </div>
        </div>
        
      </div> -->

      <br>
      <div class="row justify-content-center"> <!-- Center the row content horizontally -->
        <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
        <div class="speaker">
            <img loading="lazy"src="img/Faculty Images Updated/kamraj.webp" alt="Member" class="img-fluid" style="width: 100%; height: 100%">
            <div class="details">
              <h3>Dr. M. Kamaraj</h3>
              <p>Conference Chair</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
          <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
              <!-- Speaker details for Guest of Honor -->
              <div class="speaker">
            <img loading="lazy"src="img/Faculty Images Updated/Nirlipta Priyadarshini Nayak.webp" alt="Member" class="img-fluid" style="width: 100%; height: 100%">
            <div class="details">
              <h3>Dr. Nirlipta Priyadarshini Nayak</h3>
              <p>Convenor</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
              <!-- Speaker details for Guest of Honor -->
              <div class="speaker">
            <img loading="lazy"src="img/Faculty Images Updated/Ashish Aggarwal.webp" alt="Member" class="img-fluid">
            <div class="details">
              <h3>Dr. Ashish Aggarwal</h3>
              <p>Secretory</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
          <!-- Speaker details for Guest of Honor -->
          <div class="speaker">
            <img loading="lazy"src="img/Faculty Images Updated/Durga Madhab Mahapatra.webp" alt="Member" class="img-fluid">
            <div class="details">
              <h3>Dr. Durga Madhab Mahapatra</h3>
              <p>Joint-Secretory</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
          </div>
        </div>
      <div class="row">
        <!-- <div class="col-lg-6 col-md-6"> -->
        <!-- <div class="col-lg-12 text-center">
          <h2 class="text-center font-weight-bold"><strong>Event Convenor</strong></h2>
        </div> -->
      </div>

      <br>
  
      <!-- Committee Members -->
      <div class="row">
        <div class="col-lg-12">
          <h2 class="text-center font-weight-bold"><strong>Committee Members</strong></h2>
        </div>
      </div>
  
    
<div class="row justify-content-center"> <!-- Center the row content horizontally -->
        <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
            <!-- Speaker details for Guest of Honor -->
            <div class="speaker">
            <img loading="lazy" src="img/Faculty Images Updated/Amit Thakur.webp" alt="Member" class="img-fluid">
            <div class="details">
                <h3>Dr. Amit Thakur</h3>
                <p>Lead, Editorial Team</p>
                <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
                </div>
            </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
            <img loading="lazy" src="img/Faculty Images Updated/Dr. Vamsi Krishna Kudapa.webp" alt="Member" class="img-fluid">
            <div class="details">
            <h3>Dr. Vamsi Krishna Kudapa</h3>
            <p>Lead, Finance and Accomodation</p>
            <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
            </div>
        </div>
        </div>
         <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
        
        <div class="speaker">
            <img loading="lazy" src="img/Faculty Images Updated/Dr. Pushpa Sharma.webp" alt="Member" class="img-fluid">
            <div class="details">
            <h3>Dr. Pushpa Sharma</h3>
            <p>Lead, Sponsorship</p>
            <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
            </div>
        </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
            <!-- Speaker details for Guest of Honor -->
            <div class="speaker">
            <img loading="lazy" src="img/Faculty Images Updated/Nirlipta Priyadarshini Nayak.webp" alt="Member" class="img-fluid">
            <div class="details">
                <h3>Dr. Nirlipta Priyadarshini Nayak</h3>
                <p>Lead, Event Management</p>
                <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
                </div>
            </div>
            </div>
        </div>
    </div>
<div class="row justify-content-center"> <!-- Center the row content horizontally -->
    <div class="row" style="justify-content: center;">
      <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Ashish Aggarwal.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Ashish Aggarwal</h3>
            <p>Lead, Publicity and Outreach</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
      </div>

        <div class="col-lg-3 col-md-4 col-sm-6 mb-4"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
          <!-- Speaker details for Guest of Honor -->
          <div class="speaker">
            <img loading="lazy" src="img/Faculty Images Updated/Nitin R. Yeole.webp" alt="Member" class="img-fluid">
            <div class="details">
              <h3>Niteen Ramchandra Yeole</h3>
              <p>Lead, Food Committee</p>
              <div class="social">
                <!-- <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a> -->
              </div>
            </div>
          </div>
        </div>
   
    <div class="col-lg-3 col-md-4 col-sm-6 mb-4"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Reddy Devaparu.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Srinivasa Reddy Devarapu</h3>
            <p>Lead, Registration</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>

    <div class="col-lg-3 col-md-4 col-sm-6 mb-4"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
      <!-- Speaker details for Guest of Honor -->
      <div class="speaker">
        <img loading="lazy" src="img/Faculty Images Updated/Balachandran Singhan.webp" alt="Member" class="img-fluid">
        <div class="details">
          <h3>Mr. Bhalchandra Shingan</h3>
          <p>Lead, Hospitality & Student Support</p>
          <div class="social">
            <!-- <a href=""><i class="fa fa-twitter"></i></a>
            <a href=""><i class="fa fa-facebook"></i></a>
            <a href=""><i class="fa fa-google-plus"></i></a>
            <a href=""><i class="fa fa-linkedin"></i></a> -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

    <div class="row justify-content-center"> <!-- Center the row content horizontally -->
     
    <div class="col-lg-4 col-md-4 col-sm-6"> <!-- Adjusted column classes for 3 columns on lg screens and 2 columns on md screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Seim Timung.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Seim Timung</h3>
            <p>Lead, Transportation</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>
    </div>


<!--     
      <br>


      <div class="row">
        <div class="col-lg-12">
          <h2 class="text-center font-weight-bold"><strong>Members</strong></h2>
        </div>
      </div> -->
<hr/>
<br/>
      <!-- members -->
<div class="row justify-content-center"> <!-- Center the row content horizontally -->
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
      <!-- Speaker details for Guest of Honor -->
      <div class="speaker">
        <img loading="lazy" src="img/Faculty Images Updated/Mandira Agarwal.webp" alt="Member" class="img-fluid">
        <div class="details">
          <h3>Dr. Mandira Agarwal</h3>
          <p>Member</p>
          <div class="social">
            <!-- <a href=""><i class="fa fa-twitter"></i></a>
            <a href=""><i class="fa fa-facebook"></i></a>
            <a href=""><i class="fa fa-google-plus"></i></a>
            <a href=""><i class="fa fa-linkedin"></i></a> -->
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/G Gopal Krishnan.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. G. Gopalakrishnan</h3>
            <!-- <p>Event Management</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Dr. Sunil Kumar Khare.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Sunil Kumar Khare</h3>
            <!-- <p>Editorial Team</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Dr Ajay Mittal.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Ajay Mittal</h3>
            <!-- <p></p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>

</div>
<div class="row justify-content-center"> <!-- Center the row content horizontally -->
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
      <!-- Speaker details for Guest of Honor -->
      <div class="speaker">
        <img loading="lazy" src="img/Faculty Images Updated/Pankaj Kumar Srivastava.webp" alt="Member" class="img-fluid">
        <div class="details">
          <h3>Dr. Pankaj Kumar Srivastava</h3>
          <!-- <p>Qui molestiae natus</p> --><p>Member</p>
          <div class="social">
            <!-- <a href=""><i class="fa fa-twitter"></i></a>
            <a href=""><i class="fa fa-facebook"></i></a>
            <a href=""><i class="fa fa-google-plus"></i></a>
            <a href=""><i class="fa fa-linkedin"></i></a> -->
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Girish Chandra Kothyari.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Girish Chandra Kothyari</h3>
            <!-- <p>Qui molestiae natus</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Dr. Atul Patidar.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Atul Kumar Patidar</h3>
            <!-- <p>Qui molestiae natus</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Jagdeeshwar Kodavaty.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Jagadeeshwar Kodavaty</h3>
            <!-- <p>Qui molestiae natus</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>

</div>
<div class="row justify-content-center"> <!-- Center the row content horizontally -->
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
      <!-- Speaker details for Guest of Honor -->
      <div class="speaker">
        <img loading="lazy" src="img/Faculty Images Updated/Annapurna Boruah.webp" alt="Member" class="img-fluid">
        <div class="details">
          <h3>Dr. Annapurna Boruah</h3>
          <!-- <p>Qui molestiae natus</p> --><p>Member</p>
          <div class="social">
            <!-- <a href=""><i class="fa fa-twitter"></i></a>
            <a href=""><i class="fa fa-facebook"></i></a>
            <a href=""><i class="fa fa-google-plus"></i></a>
            <a href=""><i class="fa fa-linkedin"></i></a> -->
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Dr. Leena kapoor.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Leena Kapoor</h3>
            <!-- <p>Qui molestiae natus</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Harinandan Kumar.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Harinandan Kumar</h3>
            <!-- <p>Qui molestiae natus</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Murali Pujari.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Murali Pujari</h3>
            <!-- <p>Qui molestiae natus</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>

</div>
<div class="row justify-content-center"> <!-- Center the row content horizontally -->
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
      <!-- Speaker details for Guest of Honor -->
      <div class="speaker">
        <img loading="lazy" src="img/Faculty Images Updated/Manash Protim Mudoi.webp" alt="Member" class="img-fluid">
        <div class="details">
          <h3>Manash Protim Mudoi</h3>
          <!-- <p>Qui molestiae natus</p> --><p>Member</p>
          <div class="social">
            <!-- <a href=""><i class="fa fa-twitter"></i></a>
            <a href=""><i class="fa fa-facebook"></i></a>
            <a href=""><i class="fa fa-google-plus"></i></a>
            <a href=""><i class="fa fa-linkedin"></i></a> -->
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Trimula Rao Kotni.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Tirumala Rao Kotni</h3>
            <!-- <p>Qui molestiae natus</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Gaurav Pandey.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Gaurav Pandey</h3>
            <!-- <p>Qui molestiae natus</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6"> <!-- Adjusted column classes for 4 columns on lg screens, 3 columns on md screens, and 2 columns on sm screens -->
        <!-- Speaker details for Guest of Honor -->
        <div class="speaker">
          <img loading="lazy" src="img/Faculty Images Updated/Dr. Himanshu Kesharwani.webp" alt="Member" class="img-fluid">
          <div class="details">
            <h3>Dr. Himanshu Kesarwani</h3>
            <!-- <p>Qui molestiae natus</p> --><p>Member</p>
            <div class="social">
              <!-- <a href=""><i class="fa fa-twitter"></i></a>
              <a href=""><i class="fa fa-facebook"></i></a>
              <a href=""><i class="fa fa-google-plus"></i></a>
              <a href=""><i class="fa fa-linkedin"></i></a> -->
            </div>
          </div>
        </div>
    </div>
</div> 
</section>
